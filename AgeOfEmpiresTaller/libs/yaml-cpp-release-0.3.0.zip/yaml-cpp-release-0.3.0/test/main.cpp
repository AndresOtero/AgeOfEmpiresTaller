#include "tests.h"

int main()
{
	Test::RunAll();
	return 0;
}
